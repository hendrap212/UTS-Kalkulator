package com.aa183.pranata;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private EditText edtBil1;
    private EditText edtBil2;
    private Button btnTambah;
    private Button btnKurang;
    private Button btnBagi;
    private Button btnKali;
    private TextView tvResult;
    private String bil1;
    private String bil2;
    private Button btnmod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtBil1 = findViewById(R.id.edt_bil1);
        edtBil2 = findViewById(R.id.edt_bil2);
        btnTambah = findViewById(R.id.btn_tambh);
        btnKurang = findViewById(R.id.btn_kurang);
        btnKali = findViewById(R.id.btn_kali);
        btnBagi = findViewById(R.id.btn_bagi);
        btnmod = findViewById(R.id.btn_mod);
        tvResult = findViewById(R.id.tv_result);

        btnTambah.setOnClickListener(this);
        btnKurang.setOnClickListener(this);
        btnKali.setOnClickListener(this);
        btnBagi.setOnClickListener(this);
        btnmod.setOnClickListener(this);
    }

    private boolean validation() {
        bil1 = edtBil1.getText().toString().trim();
        bil2 = edtBil2.getText().toString().trim();
        boolean isEmptyField = false;
        if (TextUtils.isEmpty(bil1)) {
            isEmptyField = true;
            edtBil1.setError("field masih kosong");
        }
        if (TextUtils.isEmpty(bil2)) {
            isEmptyField = true;
            edtBil2.setError("field mash kosong");
        }
        return isEmptyField;
    }

    private void division() {
        double bilangan1 = Double.parseDouble(bil1);
        double bilangan2 = Double.parseDouble(bil2);
        double hasil = bilangan1 / bilangan2;
        tvResult.setText(String.valueOf(hasil));
    }

    private void multipication() {
        double bilangan1 = Double.parseDouble(bil1);
        double bilangan2 = Double.parseDouble(bil2);
        double hasil = bilangan1 * bilangan2;
        tvResult.setText(String.valueOf(hasil));
    }

    private void addition() {
        double bilangan1 = Double.parseDouble(bil1);
        double bilangan2 = Double.parseDouble(bil2);
        double hasil = bilangan1 + bilangan2;
        tvResult.setText(String.valueOf(hasil));
    }

    private void substraction() {
        double bilangan1 = Double.parseDouble(bil1);
        double bilangan2 = Double.parseDouble(bil2);
        double hasil = bilangan1 - bilangan2;
        tvResult.setText(String.valueOf(hasil));
    }

    private void mod(){
        double bilangan1 = Double.parseDouble(bil1);
        double bilangan2 = Double.parseDouble(bil2);
        double hasil = bilangan1 % bilangan2;
        tvResult.setText(String.valueOf(hasil));
    }

    @Override
    public void onClick(View v) {
        boolean isEmptyField = validation();
        switch (v.getId()) {
            case R.id.btn_tambh:
                if (!isEmptyField) {
                    addition();
                }
                break;
            case R.id.btn_kurang:
                if (!isEmptyField) {
                    substraction();
                }
                break;
            case R.id.btn_kali:
                if (!isEmptyField) {
                    multipication();
                }
                break;
            case R.id.btn_bagi:
                if (!isEmptyField) {
                    division();
                }
                break;
            case R.id.btn_mod:
                if (!isEmptyField){
                    mod();
                }
                break;

        }
    }
}